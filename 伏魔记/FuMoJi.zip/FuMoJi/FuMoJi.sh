###
 # @Descripttion: 
 # @version: 
 # @Author: JackZhang
 # @Date: 2020-10-06 13:17:09
 # @LastEditors: JackZhang
 # @LastEditTime: 2020-10-06 13:18:20
 ###
# LD_LIBRARY_PATH={your nwjs-sdk's lib} {your nw binary} {your game's folder} --use-gl=egl --ignore-gpu-blacklist --disable-accelerated-2d-canvas --num-raster-threads=2 --remote-debugging-port=9222
LD_LIBRARY_PATH=/home/cpi/apps/nwjs-sdk-v0.27.6-linux-arm/lib /home/cpi/apps/nwjs-sdk-v0.27.6-linux-arm/nw /home/cpi/apps/Menu/FuMoJi  --use-gl=egl --ignore-gpu-blacklist --disable-accelerated-2d-canvas --num-raster-threads=2 --remote-debugging-port=9222
